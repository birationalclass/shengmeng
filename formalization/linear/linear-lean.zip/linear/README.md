# Linearity Theorem — Lean attempt

This independent project follows `Luo_1005-20261006.tex` (6 October 2026).
The complete geometric Linearity Theorem is **not proved**.

`LinearStudy.LinearityTheoremGoal` is a proposition definition using actual
mathlib homogeneous polynomial coordinates, homogeneous prime ideals and
projectivizations over `ℂ`. It does not contain a proof. Comparing this
point formulation with the manuscript's Scheme formulation is a remaining
formalization obligation, as is its characteristic-zero extension.

Checked progress:

- Homogeneous evaluation scaling and independence of coordinate representatives.
- Base-point-free polynomial maps on actual projective points.
- Polynomial composition and iterate coordinate degree `q^k`.
- Total invariance and surjectivity of the restriction to an invariant subset.
- Nonzero finite-point relation functionals, extension by zero, and linear
  factorization under explicit exact-sequence hypotheses.
- The arithmetic contradiction `q^r ≤ q^(r-1)*d*m < q^r`, and selection of an
  iterate after a uniform bound is fixed.
- Previous relative-Jacobian algebraic helpers are preserved. The manuscript
  now labels that full Jacobian statement Lemma 2.1; the historical Lean target
  name `Lemma31Goal` is preserved to avoid breaking existing source references.

Unproved geometric bridges: the integral projective Scheme comparison and
dimension/degree APIs; Bertini and étale fiber counts; the complete-intersection
Jacobian/socle theorem and Euler–Jacobi relation; geometric Koszul exactness,
proper duality, Serre bounds and uniform polynomial lifting; actual Cartier
intersection and Bézout degree.

No geometric conclusion is concealed in a structure's assumption and no
`sorry`, `admit`, custom `axiom`, or imported Negativity theorem is used.
Conditional helper theorems retain their hypotheses in the exact Lean types.

## Reproduce

Pinned Lean: `leanprover/lean4:v4.35.0-rc3`.
Pinned mathlib: `2a885768dae569d938bb9ff3474da6a8753bb90a`.

```
lake update
lake exe cache get
lake build
lake env lean CheckAxioms.lean
```

The local validation used `build.py` and `audit.py` against an already installed
matching mathlib cache. It did not mutate the Negativity project or use its
mathematical declarations. Build exit codes, exact types, axiom reports and
source SHA-256 hashes are exported with this project.

The spatial proof atlas reuses the Negativity interface through its independent
Jordan Size adaptation. Its gold card identifies the current target, not a
completed proof. The full manuscript draft and private audit report are not
published; only its target, proof route and file hash are included.
