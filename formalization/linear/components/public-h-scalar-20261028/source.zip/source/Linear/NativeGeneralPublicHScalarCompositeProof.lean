module
public import Linear.NativeGeneralSourceAmbientOrderedTwistCech
public import Linear.CategoricalScalarSquareComposition
public import Linear.SchemeModuleActualCohomologyGroup
public import Linear.NativeGeneralSourceAmbientCechHomologyScalar
public import Linear.NativeSourcePublicHScalarTheorem
public import Linear.NativeOriginalHScalarCachedOperator
public import Linear.CategoricalComparisonCoefficientFactorization
public import Linear.FiniteNormalizationCoordinateCover
public import Linear.NativeSourceActualHCachedComparison
public import Linear.NativeProjectiveTwistFinitePresentation
/- Arbitrary finite coefficients;the original fraction maps,ordered signs and actual-H objects are retained.Normalized dualizing trace remains OPEN. -/
@[expose] public section
noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency true
set_option backward.isDefEq.respectTransparency.types true
set_option maxHeartbeats 5000
namespace LinearStudy
open AlgebraicGeometry CategoryTheory Opposite
universe u
variable {K R S M : Type u} [Field K] [CommRing R] [CommRing S]
variable [Algebra K R] [Algebra K S] [Algebra R S] [IsScalarTower K R S]
variable (A : ℕ → Submodule K R) [GradedAlgebra A]
variable (B : ℕ → Submodule K S) [GradedAlgebra B] [SetLike.GradedSMul A B]
variable [AddCommGroup M] [Module K M] [Module R M] [Module S M]
variable [IsScalarTower R S M] [IsScalarTower K R M] [IsScalarTower K S M]
variable (D : ℤ → Submodule K M) [DirectSum.Decomposition D]
variable (hR : ∀ n : ℕ,∀ j : ℤ,∀ z : R,z ∈ A n → ∀ x : M,x ∈ D j → z • x ∈ D ((n : ℤ)+j))
variable (hS : ∀ n : ℕ,∀ j : ℤ,∀ z : S,z ∈ B n → ∀ x : M,x ∈ D j → z • x ∈ D ((n : ℤ)+j))
variable [IsDomain R] [IsDomain S]
variable [IsNoetherianRing R] [IsNoetherianRing S] [Algebra.FiniteType K S]
variable [Module.Finite R S] [Module.Finite R M] [Module.Finite S M]
variable {ι κ : Type u} [LinearOrder ι] [Finite ι]
variable (a : ι → R) (ha : ∀ i,a i ∈ A 1)
variable (c : κ → S) (hc : ∀ i,c i ∈ B 1)
attribute [local irreducible] nativeProjectiveModuleSheaf schemeModuleToActualAbelianSheaf
  nativeIndependentSourceAmbientOrderedTwistCechIso_general

attribute [local irreducible] nativeProjectiveModulePresheaf originalGlobalModuleScalar
  orderedFormalCechComplex CategoryTheory.Limits.FormalCoproduct.evalOp
  orderedTopAbelianCechComplex orderedTopAbelianCechCoefficientMap
  nativeIndependentFiniteNormalization_cachedCechHomologyIso_general
  finiteTypeNativeProj_orderedActualHigherHIso noetherianFiniteOrderedAffineCover_actualHigherHIso
  topFiniteOrderedCech_actualHigherHIso_of_localAcyclic
  orderedFreeSheafActualHomComplexIso acyclicResolutionActualCochainExtIso
/-- The ORIGINAL actual-H coefficient square obtained by composing the
proved ambient/source Cech square with the proved original source-H square.
Both coefficient actions are retained literally; arbitrary finite graded
coefficients,including torsion,are allowed. -/
def nativeIndependentFiniteNormalization_publicActualHComposite_baseScalar_general_proof
    (hgenR : Algebra.adjoin K (Set.range a) = ⊤)
    (hgenC : Algebra.adjoin K (Set.range c) = ⊤) (k : ℤ) (q : ℕ)
    (r : Γ(Spec (CommRingCat.of K),⊤)) :=
  let b := fun i => algebraMap R S (a i)
  let hb := fun i => (normalizationBaseGradedRingHom A B).map_mem (ha i)
  let hcover := nativeFiniteNormalization_sourceCoordinateCover A B a ha hgenR
  originalEndomorphismSquare_comp (C := AddCommGrpCat.{u})
    (A := nativeProjectiveOrderedCechHomologyObject A D hR a k (q+1))
    (B := nativeProjectiveOrderedCechHomologyObject B D hS b k (q+1))
    (D := schemeModuleActualHObject (Proj B) (nativeProjectiveModuleSheaf B D hS k) (q+1))
    (nativeIndependentFiniteNormalization_cachedCechHomologyIso_baseScalar_general A B D hR hS a ha c hc hgenR hgenC k q r)
    (nativeFiniteGradedTwist_publicActualHigherHIso_baseScalar_square B D hS b hb hcover k q r)
end LinearStudy
#check LinearStudy.nativeIndependentFiniteNormalization_publicActualHComposite_baseScalar_general_proof
#print axioms LinearStudy.nativeIndependentFiniteNormalization_publicActualHComposite_baseScalar_general_proof
