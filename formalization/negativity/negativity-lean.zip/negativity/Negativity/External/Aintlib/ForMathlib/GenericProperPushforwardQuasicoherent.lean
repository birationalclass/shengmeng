module

/-
Copyright (c) 2026 Chris Birkbeck. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chris Birkbeck
-/
public import Negativity.External.Aintlib.ForMathlib.FiniteAffineOpenCover
public import Negativity.External.Aintlib.ForMathlib.SchemeModuleBaseSectionsBaseChange
public import Negativity.External.Aintlib.ForMathlib.SchemeModuleBaseCechPushforward
public import Negativity.External.Aintlib.ForMathlib.SchemeModuleQuasicoherent
public import Negativity.External.Aintlib.ForMathlib.SchemeModuleRestrictPushforward

@[expose] public section
set_option backward.defeqAttrib.useBackward true
set_option backward.isDefEq.respectTransparency false


open AlgebraicGeometry CategoryTheory CategoryTheory.Limits Opposite TopologicalSpace
open TensorProduct
open scoped ChangeOfRings
noncomputable section
universe u

namespace AlgebraicGeometry.Scheme.Modules

/-- The canonical comparison from open restriction to pullback sends a
restriction-unit section to the corresponding pullback-unit section. -/
private theorem genericProper_restrictFunctorIsoPullback_hom_unit_app_apply
    {X Y : Scheme.{u}} (f : Y ⟶ X) [IsOpenImmersion f]
    (M : X.Modules) (U : X.Opens) (x : M.val.obj (.op U)) :
    ((restrictFunctorIsoPullback f).app M).hom.val.app (.op (f ⁻¹ᵁ U))
        (((restrictAdjunction f).unit.app M).val.app (.op U) x) =
      ((pullbackPushforwardAdjunction f).unit.app M).val.app (.op U) x := by
  let adjr := restrictAdjunction f
  let adjp := pullbackPushforwardAdjunction f
  let e := (restrictFunctorIsoPullback f).app M
  have he := Adjunction.homEquiv_leftAdjointUniq_hom_app adjr adjp M
  change (adjr.homEquiv _ _) e.hom = adjp.unit.app M at he
  rw [Adjunction.homEquiv_unit] at he
  have happ := congrArg (fun q => q.val.app (.op U) x) he
  conv_lhs at happ =>
    erw [SheafOfModules.comp_val, PresheafOfModules.comp_app,
      ModuleCat.comp_apply]
  exact happ

/-- The inverse comparison from pullback to open restriction sends a pullback-unit section to
the corresponding restriction-unit section. -/
private theorem genericProper_restrictFunctorIsoPullback_inv_unit_app_apply
    {X Y : Scheme.{u}} (f : Y ⟶ X) [IsOpenImmersion f]
    (M : X.Modules) (U : X.Opens) (x : M.val.obj (.op U)) :
    ((restrictFunctorIsoPullback f).app M).inv.val.app (.op (f ⁻¹ᵁ U))
        (((pullbackPushforwardAdjunction f).unit.app M).val.app (.op U) x) =
      ((restrictAdjunction f).unit.app M).val.app (.op U) x := by
  let e := (restrictFunctorIsoPullback f).app M
  let r := ((restrictAdjunction f).unit.app M).val.app (.op U) x
  have hhom := genericProper_restrictFunctorIsoPullback_hom_unit_app_apply f M U x
  have happ := congrArg
    (fun z => e.inv.val.app (.op (f ⁻¹ᵁ U)) z) hhom
  have hcancel := congrArg (fun q => q.val.app (.op (f ⁻¹ᵁ U)) r)
    e.hom_inv_id
  conv_lhs at hcancel =>
    erw [SheafOfModules.comp_val, PresheafOfModules.comp_app,
      ModuleCat.comp_apply]
  exact happ.symm.trans hcancel

/-- On top sections, the inverse comparison from pullback to open restriction carries the
transported pullback unit to the transported restriction unit. -/
private theorem genericProper_restrictFunctorIsoPullback_inv_affinePullbackUnitTop
    {X Y : Scheme.{u}} (f : Y ⟶ X) [IsOpenImmersion f]
    (M : X.Modules) (x : M.val.obj (.op (⊤ : X.Opens))) :
    ((restrictFunctorIsoPullback f).app M).inv.val.app (.op ⊤)
        (affinePullbackUnitTop f M x) =
      (M.restrict f).presheaf.map
        (eqToHom (Scheme.Hom.preimage_top f).symm).op
        (((restrictAdjunction f).unit.app M).val.app (.op ⊤) x) := by
  let e := (restrictFunctorIsoPullback f).app M
  let P := (pullback f).obj M
  let R := M.restrict f
  let htop := Scheme.Hom.preimage_top f
  let unitTop := (((pullbackPushforwardAdjunction f).unit.app M).val.app
    (.op (⊤ : X.Opens))) x
  have hnat := e.inv.val.naturality (eqToHom htop.symm).op
  have hnatApply := ConcreteCategory.congr_hom hnat unitTop
  change e.inv.val.app (.op (⊤ : Y.Opens))
      (P.presheaf.map (eqToHom htop.symm).op unitTop) =
    R.presheaf.map (eqToHom htop.symm).op
      (e.inv.val.app (.op (f ⁻¹ᵁ (⊤ : X.Opens))) unitTop) at hnatApply
  rw [genericProper_restrictFunctorIsoPullback_inv_unit_app_apply] at hnatApply
  exact hnatApply



private theorem pullbackFst_image_top
    {X S : Scheme.{u}} (f : X ⟶ S) (U : S.Opens) :
    pullback.fst f U.ι ''ᵁ
        (⊤ : (CategoryTheory.Limits.pullback f U.ι).Opens) =
      f ⁻¹ᵁ U := by
  let t := U.ι
  let g := pullback.fst f t
  let fU := pullback.snd f t
  let H : IsPullback fU g t f :=
    (IsPullback.of_hasPullback f t).flip
  have hSquare :=
    IsOpenImmersion.image_preimage_eq_preimage_image_of_isPullback
      H (⊤ : U.toScheme.Opens)
  calc
    g ''ᵁ (⊤ : (CategoryTheory.Limits.pullback f t).Opens) =
        f ⁻¹ᵁ (t ''ᵁ (⊤ : U.toScheme.Opens)) := by
      simpa only [Scheme.Hom.preimage_top] using hSquare
    _ = f ⁻¹ᵁ U := by rw [U.ι_image_top]

private noncomputable def baseSectionsOpenRestrictIso
    {X S : Scheme.{u}} (f : X ⟶ S) (U : S.Opens) (M : X.Modules) :
    let t := U.ι
    let g := pullback.fst f t
    baseSections (g ≫ f) (M.restrict g) ≅
      (baseModulePresheaf (𝟙 S) ((pushforward f).obj M)).obj (op U) := by
  dsimp only
  let t := U.ι
  let g := pullback.fst f t
  let ePush := baseModulePresheafPushforwardAppIso f (𝟙 S) M U
  rw [Category.comp_id] at ePush
  exact baseModulePresheafRestrictAppIso f g M
      (⊤ : (CategoryTheory.Limits.pullback f t).Opens) ≪≫
    (baseModulePresheaf f M).mapIso
      (eqToIso (pullbackFst_image_top f U).symm).op ≪≫
    ePush

private theorem baseSectionsOpenRestrictIso_hom_apply
    {X S : Scheme.{u}} (f : X ⟶ S) (U : S.Opens) (M : X.Modules)
    (x : baseSections (pullback.fst f U.ι ≫ f)
      (M.restrict (pullback.fst f U.ι))) :
    (baseSectionsOpenRestrictIso f U M).hom x =
      M.presheaf.map
        (eqToHom (pullbackFst_image_top f U).symm).op
        ((M.restrictAppIso (pullback.fst f U.ι)
          (⊤ : (CategoryTheory.Limits.pullback f U.ι).Opens)).hom x) := by
  rfl

private theorem baseSectionsOpenRestrictIso_hom_pullbackUnit
    {X S : Scheme.{u}} (f : X ⟶ S) (U : S.Opens) (M : X.Modules)
    (m : Γ(M, (⊤ : X.Opens))) :
    let t := U.ι
    let g := pullback.fst f t
    let N := (pushforward f).obj M
    (baseSectionsOpenRestrictIso f U M).hom
        (((restrictFunctorIsoPullback g).app M).inv.val.app (.op ⊤)
          (affinePullbackUnitTop g M m)) =
      (baseModulePresheaf (𝟙 S) N).map U.leTop.op
        (pushforwardTopSection f M m) := by
  dsimp only
  let g := pullback.fst f U.ι
  have hUnit :=
    genericProper_restrictFunctorIsoPullback_inv_affinePullbackUnitTop g M m
  calc
    _ = (baseSectionsOpenRestrictIso f U M).hom
        ((M.restrict g).presheaf.map
          (eqToHom (Scheme.Hom.preimage_top g).symm).op
          (((restrictAdjunction g).unit.app M).val.app (.op ⊤) m)) :=
      congrArg (fun x =>
        (baseSectionsOpenRestrictIso f U M).hom x) hUnit
    _ = _ := by
      let x := (M.restrict g).presheaf.map
        (eqToHom (Scheme.Hom.preimage_top g).symm).op
        (((restrictAdjunction g).unit.app M).val.app (.op ⊤) m)
      have hOpen := baseSectionsOpenRestrictIso_hom_apply f U M x
      have hTail : M.presheaf.map
          (eqToHom (pullbackFst_image_top f U).symm).op
            ((M.restrictAppIso g
              (⊤ : (CategoryTheory.Limits.pullback f U.ι).Opens)).hom x) =
        M.presheaf.map ((Opens.map f.base).op.map U.leTop.op)
          (M.presheaf.map
            (eqToHom (Scheme.Hom.preimage_top f)).op m) := by
        dsimp only [x]
        let a := (eqToHom (Scheme.Hom.preimage_top g).symm).op
        let unitTop :=
          (((restrictAdjunction g).unit.app M).val.app (.op ⊤)) m
        have hRestrict := ConcreteCategory.congr_hom
          (M.map_restrictAppIso_hom g a) unitTop
        conv_lhs at hRestrict =>
          erw [ConcreteCategory.comp_apply]
        conv_rhs at hRestrict =>
          erw [ConcreteCategory.comp_apply]
        rw [hRestrict]
        change M.presheaf.map
            (eqToHom (pullbackFst_image_top f U).symm).op
              (M.presheaf.map
                (homOfLE (Scheme.Hom.image_mono g
                  (leOfHom a.unop))).op unitTop) =
          M.presheaf.map ((Opens.map f.base).op.map U.leTop.op)
            (M.presheaf.map
              (eqToHom (Scheme.Hom.preimage_top f)).op m)
        dsimp only [unitTop]
        have hAdj := ConcreteCategory.congr_hom
          (restrictAdjunction_unit_app_app g M (⊤ : X.Opens)) m
        change (((restrictAdjunction g).unit.app M).val.app (.op ⊤)) m =
          M.presheaf.map
            (homOfLE (g.image_preimage_le (⊤ : X.Opens))).op m at hAdj
        rw [hAdj]
        rw [← M.presheaf.map_comp_apply, ← M.presheaf.map_comp_apply]
        conv_rhs => erw [← M.presheaf.map_comp_apply]
        exact ConcreteCategory.congr_hom
          (M.presheaf.congr_map (Subsingleton.elim _ _)) m
      exact hOpen.trans hTail

private theorem baseSectionsEqToIso_hom_apply
    {X S : Scheme.{u}} {q q' : X ⟶ S} (hq : q = q') (M : X.Modules)
    (x : baseSections q M) :
    (eqToIso (congrArg (fun k => baseSections k M) hq)).hom x = x := by
  subst q'
  rfl

private noncomputable def baseSectionsOpenAfterIso
    {X S : Scheme.{u}} (f : X ⟶ S) (U : S.Opens) (M : X.Modules) :
    let t := U.ι
    let g := pullback.fst f t
    let fU := pullback.snd f t
    (ModuleCat.restrictScalars t.appTop.hom).obj
        (baseSections fU (M.restrict g)) ≅
      (baseModulePresheaf (𝟙 S) ((pushforward f).obj M)).obj (op U) := by
  dsimp only
  let t := U.ι
  let g := pullback.fst f t
  let fU := pullback.snd f t
  exact baseSectionsCompIso fU t (M.restrict g) ≪≫
    eqToIso (congrArg (fun q => baseSections q (M.restrict g))
      pullback.condition.symm) ≪≫
    baseSectionsOpenRestrictIso f U M

private theorem baseSectionsOpenAfterIso_hom_apply
    {X S : Scheme.{u}} (f : X ⟶ S) (U : S.Opens) (M : X.Modules)
    (x : baseSections (pullback.snd f U.ι)
      (M.restrict (pullback.fst f U.ι))) :
    (baseSectionsOpenAfterIso f U M).hom x =
      (baseSectionsOpenRestrictIso f U M).hom x := by
  dsimp only [baseSectionsOpenAfterIso]
  conv_lhs =>
    erw [ModuleCat.comp_apply, ModuleCat.comp_apply]
  rw [baseSectionsCompIso_hom_apply]
  have hEq := baseSectionsEqToIso_hom_apply pullback.condition.symm
    (M.restrict (pullback.fst f U.ι)) x
  exact congrArg
    (fun y => (baseSectionsOpenRestrictIso f U M).hom y) hEq

private theorem baseSectionsOpenAfterIso_hom_pullbackUnit
    {X S : Scheme.{u}} (f : X ⟶ S) (U : S.Opens) (M : X.Modules)
    (m : Γ(M, (⊤ : X.Opens))) :
    let g := pullback.fst f U.ι
    (baseSectionsOpenAfterIso f U M).hom
        (((restrictFunctorIsoPullback g).app M).inv.val.app (.op ⊤)
          (affinePullbackUnitTop g M m)) =
      (baseModulePresheaf (𝟙 S) ((pushforward f).obj M)).map U.leTop.op
        (pushforwardTopSection f M m) := by
  dsimp only
  let g := pullback.fst f U.ι
  let x := ((restrictFunctorIsoPullback g).app M).inv.val.app (.op ⊤)
    (affinePullbackUnitTop g M m)
  have hAfter := baseSectionsOpenAfterIso_hom_apply f U M x
  exact hAfter.trans
    (baseSectionsOpenRestrictIso_hom_pullbackUnit f U M m)

private noncomputable def
    baseSectionsRestrictLinearEquivOfOrderedCechKernelComparison
    {X S T : Scheme.{u}} (f : X ⟶ S) (t : T ⟶ S) (M : X.Modules)
    {ι : Type u} [Fintype ι] [LinearOrder ι] (U : ι → X.Opens)
    (hU : IsOpenCover U) (hUaff : ∀ i, IsAffineOpen (U i))
    [X.IsSeparated] [IsAffine S] [IsAffine T] [M.IsQuasicoherent]
    [IsOpenImmersion t]
    (hker :
      letI : Algebra Γ(S, (⊤ : S.Opens)) Γ(T, (⊤ : T.Opens)) :=
        t.appTop.hom.toAlgebra
      Function.Bijective
        (ModularCurves.kerBaseChangeComparison Γ(T, (⊤ : T.Opens))
          ((orderedBaseCechComplex f M U).d 0 1).hom)) :
    let B := Γ(S, (⊤ : S.Opens))
    let A := Γ(T, (⊤ : T.Opens))
    letI : Algebra B A := t.appTop.hom.toAlgebra
    let g := pullback.fst f t
    let fT := pullback.snd f t
    A ⊗[B] baseSections f M ≃ₗ[A]
      baseSections fT (M.restrict g) := by
  dsimp only
  let g := pullback.fst f t
  let fT := pullback.snd f t
  let B := Γ(S, (⊤ : S.Opens))
  let A := Γ(T, (⊤ : T.Opens))
  letI : Algebra B A := t.appTop.hom.toAlgebra
  letI : IsOpenImmersion g :=
    MorphismProperty.pullback_fst f t inferInstance
  let ePullback :=
    baseSectionsBaseChangeLinearEquivOfOrderedCechKernelComparison
      f t M U hU hUaff hker
  let eRestrict := (baseSectionsMapIso fT
    ((restrictFunctorIsoPullback g).app M)).symm.toLinearEquiv
  exact ePullback.trans eRestrict

private theorem
    baseSectionsRestrictLinearEquivOfOrderedCechKernelComparison_one_tmul
    {X S T : Scheme.{u}} (f : X ⟶ S) (t : T ⟶ S) (M : X.Modules)
    {ι : Type u} [Fintype ι] [LinearOrder ι] (U : ι → X.Opens)
    (hU : IsOpenCover U) (hUaff : ∀ i, IsAffineOpen (U i))
    [X.IsSeparated] [IsAffine S] [IsAffine T] [M.IsQuasicoherent]
    [IsOpenImmersion t]
    (hker :
      letI : Algebra Γ(S, (⊤ : S.Opens)) Γ(T, (⊤ : T.Opens)) :=
        t.appTop.hom.toAlgebra
      Function.Bijective
        (ModularCurves.kerBaseChangeComparison Γ(T, (⊤ : T.Opens))
          ((orderedBaseCechComplex f M U).d 0 1).hom))
    (s : baseSections f M) :
    let B := Γ(S, (⊤ : S.Opens))
    let A := Γ(T, (⊤ : T.Opens))
    letI : Algebra B A := t.appTop.hom.toAlgebra
    let g := pullback.fst f t
    baseSectionsRestrictLinearEquivOfOrderedCechKernelComparison
        f t M U hU hUaff hker ((1 : A) ⊗ₜ[B] s) =
      ((restrictFunctorIsoPullback g).app M).inv.val.app (.op ⊤)
        (affinePullbackUnitTop g M s) := by
  dsimp only
  let g := pullback.fst f t
  let fT := pullback.snd f t
  let B := Γ(S, (⊤ : S.Opens))
  let A := Γ(T, (⊤ : T.Opens))
  letI : Algebra B A := t.appTop.hom.toAlgebra
  letI : IsOpenImmersion g :=
    MorphismProperty.pullback_fst f t inferInstance
  let ePullback :=
    baseSectionsBaseChangeLinearEquivOfOrderedCechKernelComparison
      f t M U hU hUaff hker
  let eRestrictIso := baseSectionsMapIso fT
    ((restrictFunctorIsoPullback g).app M)
  dsimp only [baseSectionsRestrictLinearEquivOfOrderedCechKernelComparison]
  change eRestrictIso.inv (ePullback ((1 : A) ⊗ₜ[B] s)) = _
  rw [baseSectionsBaseChangeLinearEquivOfOrderedCechKernelComparison_one_tmul]
  rfl

private noncomputable def finiteAffineCoverBasicOpenBaseSectionsEquiv
    {X S : Scheme.{u}} (f : X ⟶ S) (M : X.Modules)
    {ι : Type u} [Fintype ι] [LinearOrder ι] (U : ι → X.Opens)
    (hU : IsOpenCover U) (hUaff : ∀ i, IsAffineOpen (U i))
    [X.IsSeparated] [IsAffine S] [M.IsQuasicoherent]
    (r : Γ(S, (⊤ : S.Opens))) :
    let V := S.basicOpen r
    let B := Γ(S, (⊤ : S.Opens))
    let A := Γ(V.toScheme, (⊤ : V.toScheme.Opens))
    letI : Algebra B A := V.ι.appTop.hom.toAlgebra
    TensorProduct B A (baseSections f M) ≃ₗ[B]
      (baseModulePresheaf (𝟙 S) ((pushforward f).obj M)).obj (op V) := by
  dsimp only
  let V := S.basicOpen r
  let t := V.ι
  let B := Γ(S, (⊤ : S.Opens))
  let A := Γ(V.toScheme, (⊤ : V.toScheme.Opens))
  letI : Algebra B A := t.appTop.hom.toAlgebra
  letI : IsLocalization.Away r A := inferInstance
  letI : Module.Flat B A :=
    IsLocalization.flat A (Submonoid.powers r)
  let hker := ModularCurves.kerBaseChangeComparison_bijective_of_flat
    (A := A) (f := ((orderedBaseCechComplex f M U).d 0 1).hom)
  let eBefore :=
    baseSectionsRestrictLinearEquivOfOrderedCechKernelComparison
      f t M U hU hUaff hker
  let eBeforeB := ((ModuleCat.restrictScalars t.appTop.hom).mapIso
    eBefore.toModuleIso).toLinearEquiv
  let eAfter := (baseSectionsOpenAfterIso f V M).toLinearEquiv
  exact eBeforeB.trans eAfter

private theorem finiteAffineCoverBasicOpenBaseSectionsEquiv_one_tmul
    {X S : Scheme.{u}} (f : X ⟶ S) (M : X.Modules)
    {ι : Type u} [Fintype ι] [LinearOrder ι] (U : ι → X.Opens)
    (hU : IsOpenCover U) (hUaff : ∀ i, IsAffineOpen (U i))
    [X.IsSeparated] [IsAffine S] [M.IsQuasicoherent]
    (r : Γ(S, (⊤ : S.Opens))) (s : baseSections f M) :
    let V := S.basicOpen r
    let B := Γ(S, (⊤ : S.Opens))
    let A := Γ(V.toScheme, (⊤ : V.toScheme.Opens))
    letI : Algebra B A := V.ι.appTop.hom.toAlgebra
    finiteAffineCoverBasicOpenBaseSectionsEquiv f M U hU hUaff r
        ((1 : A) ⊗ₜ[B] s) =
      (baseModulePresheaf (𝟙 S) ((pushforward f).obj M)).map V.leTop.op
        (pushforwardTopSection f M s) := by
  dsimp only
  let V := S.basicOpen r
  let t := V.ι
  let g := pullback.fst f t
  let B := Γ(S, (⊤ : S.Opens))
  let A := Γ(V.toScheme, (⊤ : V.toScheme.Opens))
  letI : Algebra B A := t.appTop.hom.toAlgebra
  letI : IsLocalization.Away r A := inferInstance
  letI : Module.Flat B A :=
    IsLocalization.flat A (Submonoid.powers r)
  let hker := ModularCurves.kerBaseChangeComparison_bijective_of_flat
    (A := A) (f := ((orderedBaseCechComplex f M U).d 0 1).hom)
  let eBefore :=
    baseSectionsRestrictLinearEquivOfOrderedCechKernelComparison
      f t M U hU hUaff hker
  let eBeforeB := ((ModuleCat.restrictScalars t.appTop.hom).mapIso
    eBefore.toModuleIso).toLinearEquiv
  let eAfter := (baseSectionsOpenAfterIso f V M).toLinearEquiv
  have hBefore :=
    baseSectionsRestrictLinearEquivOfOrderedCechKernelComparison_one_tmul
      f t M U hU hUaff hker s
  have hBeforeB : eBeforeB ((1 : A) ⊗ₜ[B] s) =
      ((restrictFunctorIsoPullback g).app M).inv.val.app (.op ⊤)
        (affinePullbackUnitTop g M s) := hBefore
  have hAfter := baseSectionsOpenAfterIso_hom_pullbackUnit f V M s
  have hMain :
      finiteAffineCoverBasicOpenBaseSectionsEquiv f M U hU hUaff r =
        eBeforeB.trans eAfter := rfl
  have hMainApply := congrArg
    (fun e => e ((1 : A) ⊗ₜ[B] s)) hMain
  have hTrans := LinearEquiv.trans_apply
    (e₁₂ := eBeforeB) (e₂₃ := eAfter) ((1 : A) ⊗ₜ[B] s)
  calc
    _ = eAfter (eBeforeB ((1 : A) ⊗ₜ[B] s)) := hMainApply.trans hTrans
    _ = _ := congrArg (fun x => eAfter x) hBeforeB |>.trans hAfter

end AlgebraicGeometry.Scheme.Modules

namespace AlgebraicGeometry.Scheme.Modules

private theorem isQuasicoherent_of_basicOpen_tensorEquiv_of_topEquiv
    {S : Scheme.{u}} [IsAffine S] (N : S.Modules)
    (P : ModuleCat.{u} Γ(S, (⊤ : S.Opens)))
    (eTop : P ≃ₗ[Γ(S, (⊤ : S.Opens))]
      (Scheme.Modules.baseModulePresheaf (𝟙 S) N).obj
        (op (⊤ : S.Opens)))
    (eOpen : ∀ r : Γ(S, (⊤ : S.Opens)),
      let U := S.basicOpen r
      let B := Γ(S, (⊤ : S.Opens))
      let A := Γ(U.toScheme, (⊤ : U.toScheme.Opens))
      letI : Algebra B A := U.ι.appTop.hom.toAlgebra
      TensorProduct B A P ≃ₗ[B]
        (Scheme.Modules.baseModulePresheaf (𝟙 S) N).obj (op U))
    (heOpen : ∀ (r : Γ(S, (⊤ : S.Opens))) (p : P),
      let U := S.basicOpen r
      let B := Γ(S, (⊤ : S.Opens))
      let A := Γ(U.toScheme, (⊤ : U.toScheme.Opens))
      letI : Algebra B A := U.ι.appTop.hom.toAlgebra
      eOpen r ((1 : A) ⊗ₜ[B] p) =
        (Scheme.Modules.baseModulePresheaf (𝟙 S) N).map U.leTop.op
          (eTop p)) :
    N.IsQuasicoherent := by
  apply Scheme.Modules.isQuasicoherent_of_isLocalized_basicOpen N
  intro r
  let U := S.basicOpen r
  let B := Γ(S, (⊤ : S.Opens))
  let A := Γ(U.toScheme, (⊤ : U.toScheme.Opens))
  letI : Algebra B A := U.ι.appTop.hom.toAlgebra
  let er := eOpen r
  let localizationUnit : P →ₗ[B] TensorProduct B A P :=
    TensorProduct.mk B A P 1
  let target := er.toLinearMap.comp localizationUnit
  let ψ := ((Scheme.Modules.baseModulePresheaf (𝟙 S) N).map U.leTop.op).hom
  let composedRestriction := ψ.comp eTop.toLinearMap
  letI : IsLocalization.Away r A := inferInstance
  letI : IsLocalizedModule.Away r localizationUnit := inferInstance
  letI : IsLocalizedModule.Away r target :=
    IsLocalizedModule.of_linearEquiv
      (Submonoid.powers r) localizationUnit er
  have hTarget : IsLocalizedModule.Away r target := inferInstance
  have hRestriction : target = composedRestriction := by
    ext p
    have hUnit : target p = er ((1 : A) ⊗ₜ[B] p) := by
      dsimp only [target, localizationUnit]
      rw [LinearMap.comp_apply]
      exact congrArg (fun y => er y)
        (TensorProduct.mk_apply (R := B) (M := A) (N := P) (1 : A) p)
    have hGenerator := heOpen r p
    have hComposed : composedRestriction p = ψ (eTop p) := by
      dsimp only [composedRestriction]
      rw [LinearMap.comp_apply]
      rfl
    rw [hUnit, hGenerator]
    exact hComposed.symm
  have hComposedLocalized :
      IsLocalizedModule.Away r composedRestriction := by
    rw [← hRestriction]
    exact hTarget
  exact (IsLocalizedModule.comp_iff_of_bijective_right
    (S := Submonoid.powers r) eTop.toLinearMap eTop.bijective).mp
      hComposedLocalized

/-- Pushforward to an affine scheme is quasicoherent when the source is separated
and has a finite affine open cover. -/
theorem isQuasicoherent_pushforward_of_finiteAffineCover
    {X S : Scheme.{u}} (f : X ⟶ S) (M : X.Modules)
    {ι : Type u} [Fintype ι] [LinearOrder ι] (U : ι → X.Opens)
    (hU : IsOpenCover U) (hUaff : ∀ i, IsAffineOpen (U i))
    [X.IsSeparated] [IsAffine S] [M.IsQuasicoherent] :
    ((Scheme.Modules.pushforward f).obj M).IsQuasicoherent := by
  let N := (Scheme.Modules.pushforward f).obj M
  let eTopIso := Scheme.Modules.baseSectionsPushforwardTopIso f M
  let eTop := eTopIso.toLinearEquiv
  let eOpen := fun r =>
    Scheme.Modules.finiteAffineCoverBasicOpenBaseSectionsEquiv
      f M U hU hUaff r
  apply Scheme.Modules.isQuasicoherent_of_basicOpen_tensorEquiv_of_topEquiv N
    (Scheme.Modules.baseSections f M) eTop eOpen
  intro r s
  let V := S.basicOpen r
  let ψ := ((Scheme.Modules.baseModulePresheaf (𝟙 S) N).map V.leTop.op).hom
  have hOpen :=
    Scheme.Modules.finiteAffineCoverBasicOpenBaseSectionsEquiv_one_tmul
      f M U hU hUaff r s
  have hTop : eTopIso.hom s =
      Scheme.Modules.pushforwardTopSection f M s := rfl
  have hTopMapped := congrArg (fun y => ψ y) hTop.symm
  exact hOpen.trans hTopMapped

/-- Pushforward of a quasicoherent module along a proper morphism to an
affine scheme is quasicoherent. -/
theorem isQuasicoherent_pushforward_of_isProper_to_affine
    {X S : Scheme.{u}} (f : X ⟶ S) [IsProper f] [IsAffine S]
    (M : X.Modules) [M.IsQuasicoherent] :
    ((pushforward f).obj M).IsQuasicoherent := by
  letI : X.IsSeparated := ⟨by
    rw [← terminal.comp_from f]
    infer_instance⟩
  obtain ⟨ι, hι, U, hU, hUaff, _⟩ :=
    f.exists_finite_affine_openCover_of_isProper
  letI : Finite ι := hι
  letI : Fintype ι := Fintype.ofFinite ι
  letI : LinearOrder ι :=
    LinearOrder.lift' (Fintype.equivFin ι) (Fintype.equivFin ι).injective
  exact isQuasicoherent_pushforward_of_finiteAffineCover
    f M U hU hUaff

end AlgebraicGeometry.Scheme.Modules
