import Negativity

#print axioms Negativity.exists_effective_shift
#print axioms Negativity.effective_of_curve_tests
#print axioms Negativity.effective_push
#print axioms Negativity.negative_is_exceptional
#print axioms Negativity.exists_least_effective_shift
#print axioms Negativity.effective_iff_push_effective
#print axioms Negativity.exceptional_subset_support
#print axioms Negativity.fiber_support_dichotomy
#print axioms Negativity.push_comp
#print axioms Negativity.push_zero_iff_exceptional_support
#print axioms Negativity.effective_both_signs_iff_zero
#print axioms Negativity.nonpositive_smul
#print axioms Negativity.nonpositive_pullback
#print axioms Negativity.effective_descends
#print axioms Negativity.negativity_descends
#print axioms Negativity.subset_iff_preimage_subset
#print axioms Negativity.disjoint_iff_preimage_disjoint
#print axioms Negativity.support_dichotomy_descends
#print axioms Negativity.composite_fiber
#print axioms Negativity.fiber_dichotomy_descends
#print axioms Negativity.push_embDomain
#print axioms Negativity.push_add_exceptional
#print axioms Negativity.effective_descends_coefficients
#print axioms Negativity.scheme_cycle_map_effective
#print axioms Negativity.scheme_mapCoeff_zero_of_drop
#print axioms Negativity.scheme_mapCoeff_of_same_weight
#print axioms Negativity.scheme_cycle_map_zero_of_drop

#print axioms Negativity.scheme_cycle_map_single
#print axioms Negativity.scheme_curve_push_of_same_weight
#print axioms Negativity.scheme_curve_push_of_drop
#print axioms Negativity.projection_cases_from_cycle_push
#print axioms Negativity.nonpositive_pullback_from_cycle_push
#print axioms Negativity.projection_formula_on_real_span
#print axioms Negativity.scheme_effective_descends

#print axioms Negativity.dvr_order_ringEquiv
#print axioms Negativity.dvr_fraction_order_well_defined
#print axioms Negativity.dvr_fraction_order_ringEquiv
#print axioms Negativity.scheme_pushpull_of_local_coefficients
#print axioms Negativity.scheme_stalk_fraction_order_of_iso
#print axioms Negativity.scheme_residueDegree_of_iso
#print axioms Negativity.scheme_residueDegree_of_stalk_iso
#print axioms Negativity.scheme_pushpull_of_local_isomorphisms

#print axioms Negativity.normal_one_dimensional_local_isDVR
#print axioms Negativity.scheme_normal_one_dimensional_stalk_isDVR
#print axioms Negativity.proper_dvr_lift
#print axioms Negativity.proper_valuative_lift_unique
#print axioms Negativity.proper_quasiFinite_isFinite
#print axioms Negativity.proper_finite_fiber_neighborhood
