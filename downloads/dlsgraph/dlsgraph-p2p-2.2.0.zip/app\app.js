"use strict";

const MAX_MEMBERS = 5;
const SIGNAL_PREFIX = "dlsgraph-p2p1.";
const INVITE_PREFIX = "DLSGRAPH-P2P2|";
const LEGACY_INVITE_PREFIX = "DLSGRAPH-P2P1|";
const TURN_RELAY_MIN = 49160;
const TURN_RELAY_MAX = 49200;
const signalCandidates = [
  { name: "ntfy.adminforge.de · 德国（社区）", url: "https://ntfy.adminforge.de/" },
  { name: "ntfy.sh · 美国（官方）", url: "https://ntfy.sh/" },
  { name: "ntfy.hostux.net · 法国（社区）", url: "https://ntfy.hostux.net/" },
  { name: "ntfy.mzte.de · 德国（社区）", url: "https://ntfy.mzte.de/" },
  { name: "ntfy.tedomum.fr · 法国（社区）", url: "https://ntfy.tedomum.fr/" },
  { name: "ntfy.envs.net · 德国（社区）", url: "https://ntfy.envs.net/" }
];

const $ = id => document.getElementById(id);
const ui = {
  name: $("nameInput"), room: $("roomInput"), secret: $("secretInput"),
  showSecret: $("showSecretButton"), randomSecret: $("randomSecretButton"),
  server: $("serverSelect"), customServer: $("customServerInput"), probe: $("probeButton"),
  host: $("hostButton"), hostPanel: $("hostPanel"), hostStatus: $("hostStatusBadge"),
  hostNetworkWarning: $("hostNetworkWarning"),
  hostPublicIp: $("hostPublicIpInput"), detectPublicIp: $("detectPublicIpButton"),
  hostPort: $("hostPortInput"), hostUsername: $("hostUsernameInput"), hostPassword: $("hostPasswordInput"),
  startHost: $("startHostButton"), pasteInvite: $("pasteInviteButton"),
  copyInvite: $("copyInviteButton"), connect: $("connectButton"),
  statusDot: $("statusDot"), statusText: $("statusText"), signalLatency: $("signalLatency"),
  directSummary: $("directSummary"), turnSummary: $("turnSummary"), averageLatency: $("averageLatency"),
  memberCount: $("memberCount"), members: $("membersList"), quality: $("qualityButton"),
  routeBadge: $("routeBadge"), messages: $("messages"), messageEmpty: $("messageEmpty"),
  message: $("messageInput"), send: $("sendButton"), toast: $("toast"),
  modalBackdrop: $("modalBackdrop"), modalTitle: $("modalTitle"), modalBody: $("modalBody"),
  modalClose: $("modalClose"), modalConfirm: $("modalConfirm")
};

const state = {
  connected: false,
  connecting: false,
  signalOpen: false,
  selfId: "",
  name: "",
  room: "",
  secret: "",
  server: "",
  turnConfig: null,
  turnConfigSource: "",
  pendingHostConfig: null,
  turnHostStatus: "stopped",
  vpnDetected: false,
  topic: "",
  cryptoKey: null,
  eventSource: null,
  peers: new Map(),
  seenMessages: new Set(),
  heartbeatTimer: null,
  cleanupTimer: null,
  pingTimer: null,
  signalProbeMs: null,
  qualityRunning: false,
  reconnectNoticeShown: false,
  signalQueue: Promise.resolve(),
  signalGeneration: 0
};

const integration = {
  enabled: new URLSearchParams(location.search).get("integration") === "1",
  reported: false,
  completing: false,
  role: new URLSearchParams(location.search).get("role") || "test",
  expected: Math.max(2, Math.min(5, Number(new URLSearchParams(location.search).get("expected")) || 2)),
  forceRelay: new URLSearchParams(location.search).get("forceRelay") === "1"
};

const hostUiTest = {
  enabled: new URLSearchParams(location.search).get("hostUiTest") === "1",
  sawRunning: false,
  reported: false
};

function randomId(bytes = 16) {
  const data = crypto.getRandomValues(new Uint8Array(bytes));
  return Array.from(data, b => b.toString(16).padStart(2, "0")).join("");
}

function randomSecret() {
  const data = crypto.getRandomValues(new Uint8Array(15));
  return bytesToBase64Url(data);
}

function normalizeServer(value) {
  let text = String(value || "").trim();
  if (!text) throw new Error("服务器地址不能为空");
  if (!text.includes("://")) text = "https://" + text;
  const url = new URL(text);
  const localHttp = url.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
  if (url.protocol !== "https:" && !localHttp) throw new Error("公共服务器必须使用 HTTPS");
  if (url.search || url.hash) throw new Error("服务器地址不能包含查询参数或片段");
  return url.href.replace(/\/+$/, "") + "/";
}

function normalizeTurnUrl(value) {
  const text = String(value || "").trim();
  const match = /^(turns?):(\[[0-9a-f:]+\]|[a-z0-9.-]+):(\d{1,5})(?:\?transport=(udp|tcp))?$/i.exec(text);
  if (!match) throw new Error("TURN 地址格式无效");
  const port = Number(match[3]);
  if (port < 1 || port > 65535) throw new Error("TURN 端口无效");
  return match[1].toLowerCase() + ":" + match[2] + ":" + port
    + (match[4] ? "?transport=" + match[4].toLowerCase() : "");
}

function normalizeTurnConfig(config) {
  if (!config) return null;
  const sourceUrls = Array.isArray(config.urls) ? config.urls : [config.urls];
  const urls = Array.from(new Set(sourceUrls.filter(Boolean).map(normalizeTurnUrl))).slice(0, 3);
  const username = String(config.username || "").trim();
  const credential = String(config.credential || "").trim();
  if (!urls.length || !/^[A-Za-z0-9_-]{4,48}$/.test(username) || !/^[A-Za-z0-9_-]{12,96}$/.test(credential))
    throw new Error("TURN 主机凭据不完整或格式无效");
  return { urls, username, credential };
}

function parseIpv4(value) {
  const text = String(value || "").trim();
  const octets = text.split(".");
  if (octets.length !== 4 || octets.some(part => !/^\d{1,3}$/.test(part) || Number(part) > 255))
    throw new Error("请输入有效的公网 IPv4 地址");
  return octets.map(Number).join(".");
}

function readHostTurnConfig() {
  const publicIp = parseIpv4(ui.hostPublicIp.value);
  const port = Number(ui.hostPort.value);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("TURN 端口必须在 1 到 65535 之间");
  const username = ui.hostUsername.value.trim();
  const credential = ui.hostPassword.value.trim();
  return normalizeTurnConfig({
    urls: ["turn:" + publicIp + ":" + port + "?transport=udp", "turn:" + publicIp + ":" + port + "?transport=tcp"],
    username,
    credential
  });
}

function getIceConfiguration() {
  const iceServers = [
    { urls: "stun:stun.cloudflare.com:3478" },
    { urls: "stun:stun.l.google.com:19302" }
  ];
  if (state.turnConfig) iceServers.push(state.turnConfig);
  return {
    iceServers,
    iceCandidatePoolSize: 4,
    iceTransportPolicy: integration.forceRelay ? "relay" : "all"
  };
}

function bytesToBase64(bytes) {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 0x8000) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + 0x8000, bytes.length)));
  }
  return btoa(binary);
}

function base64ToBytes(value) {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function bytesToBase64Url(bytes) {
  return bytesToBase64(bytes).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64UrlToBytes(value) {
  let padded = value.replace(/-/g, "+").replace(/_/g, "/");
  while (padded.length % 4) padded += "=";
  return base64ToBytes(padded);
}

function textToBase64Url(value) {
  return bytesToBase64Url(new TextEncoder().encode(value));
}

function base64UrlToText(value) {
  return new TextDecoder().decode(base64UrlToBytes(value));
}

async function sha256(value) {
  return new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)));
}

async function deriveCryptoKey(room, secret) {
  const material = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(secret), "PBKDF2", false, ["deriveKey"]);
  const salt = await sha256("dlsgraph-p2p-keys|" + room.trim().toLowerCase());
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
    material,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]);
}

async function createTopic(room, secret) {
  const digest = await sha256("dlsgraph-p2p-topic|" + room.trim().toLowerCase() + "|" + secret);
  return "dlsgraph-p2p-" + Array.from(digest.slice(0, 18), b => b.toString(16).padStart(2, "0")).join("");
}

async function encryptObject(object) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plain = new TextEncoder().encode(JSON.stringify(object));
  const encrypted = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, state.cryptoKey, plain));
  const envelope = new Uint8Array(iv.length + encrypted.length);
  envelope.set(iv, 0);
  envelope.set(encrypted, iv.length);
  return SIGNAL_PREFIX + bytesToBase64(envelope);
}

async function decryptObject(payload) {
  if (typeof payload !== "string" || !payload.startsWith(SIGNAL_PREFIX)) throw new Error("不支持的加密消息");
  const envelope = base64ToBytes(payload.slice(SIGNAL_PREFIX.length));
  if (envelope.length < 29) throw new Error("加密消息长度无效");
  const iv = envelope.slice(0, 12);
  const cipher = envelope.slice(12);
  const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, state.cryptoKey, cipher);
  return JSON.parse(new TextDecoder().decode(plain));
}

async function probeServer(server) {
  const normalized = normalizeServer(server);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 7000);
  const started = performance.now();
  try {
    const topic = "dlsgraph-probe-" + randomId(10);
    const response = await fetch(normalized + topic + "?cache=no", {
      method: "POST",
      body: "dlsgraph p2p relay probe",
      signal: controller.signal,
      cache: "no-store"
    });
    if (!response.ok) throw new Error("HTTP " + response.status);
    return { server: normalized, ok: true, ms: Math.round(performance.now() - started) };
  } catch (error) {
    return { server: normalized, ok: false, ms: Math.round(performance.now() - started), error: error.message };
  } finally {
    clearTimeout(timeout);
  }
}

async function autoSelectServer(showResults = true) {
  setConnectionBusy(true, "正在并行测速…");
  const results = await Promise.all(signalCandidates.map(item => probeServer(item.url)));
  const successes = results.filter(item => item.ok).sort((a, b) => a.ms - b.ms);
  setConnectionBusy(false);
  if (!successes.length) {
    setStatus("error", "没有找到可用的公共信令服务器");
    showModalText("测速失败", "所有内置节点均不可用。请检查网络，或选择“自定义”并填写自己的 ntfy 地址。");
    throw new Error("没有可用服务器");
  }
  const best = successes[0];
  ui.server.value = best.server;
  ui.customServer.classList.add("hidden");
  state.signalProbeMs = best.ms;
  ui.signalLatency.textContent = best.ms + " ms";
  setStatus("idle", "已选择 " + new URL(best.server).hostname);

  if (showResults) {
    const body = document.createElement("div");
    successes.slice(0, 4).forEach((result, index) => {
      const row = document.createElement("div");
      row.className = "result-row";
      const name = signalCandidates.find(x => x.url === result.server)?.name || new URL(result.server).hostname;
      const left = document.createElement("strong");
      left.textContent = (index + 1) + ". " + name;
      const right = document.createElement("span");
      right.textContent = result.ms + " ms";
      row.append(left, right);
      body.appendChild(row);
    });
    const note = document.createElement("p");
    note.textContent = "这里只影响成员发现和握手；连接建立后的聊天延时以成员列表中的 P2P RTT 为准。";
    body.appendChild(note);
    showModal("信令服务器测速", body);
  }
  return best.server;
}

async function resolveServer(testManual = false) {
  if (ui.server.value === "auto") return autoSelectServer(false);
  const value = ui.server.value === "custom" ? ui.customServer.value : ui.server.value;
  const server = normalizeServer(value);
  if (testManual) {
    const result = await probeServer(server);
    if (!result.ok) throw new Error("服务器不可用：" + (result.error || "未知错误"));
    state.signalProbeMs = result.ms;
    ui.signalLatency.textContent = result.ms + " ms";
  }
  return server;
}

function setTurnHostStatus(status, detail) {
  state.turnHostStatus = status;
  ui.hostStatus.className = "host-status " + (status === "stopped" ? "idle" : status);
  const labels = {
    stopped: "尚未启动",
    starting: "正在启动",
    running: "主机运行中",
    error: "启动失败"
  };
  ui.hostStatus.textContent = labels[status] || status;
  ui.startHost.textContent = status === "running" ? "停止主机" : (status === "starting" ? "启动中…" : "启动主机");
  ui.startHost.disabled = status === "starting";
  const lock = status === "starting" || status === "running";
  [ui.hostPublicIp, ui.hostPort, ui.hostUsername, ui.hostPassword, ui.detectPublicIp].forEach(control => { control.disabled = lock; });

  if (status === "running" && state.pendingHostConfig) {
    state.turnConfig = state.pendingHostConfig;
    state.turnConfigSource = "host";
    state.pendingHostConfig = null;
  } else if ((status === "stopped" || status === "error") && state.turnConfigSource === "host") {
    state.turnConfig = null;
    state.turnConfigSource = "";
  }
  ui.turnSummary.textContent = state.turnConfig ? (state.turnConfigSource === "host" ? "本机主机" : "已配置") : "未配置";
  if (detail && status === "error") showModalText("TURN 主机启动失败", detail);

  if (hostUiTest.enabled && !hostUiTest.reported) {
    if (status === "running") {
      hostUiTest.sawRunning = true;
      window.chrome?.webview?.postMessage({ type: "turn-host-stop" });
    } else if (status === "stopped" && hostUiTest.sawRunning) {
      hostUiTest.reported = true;
      window.chrome?.webview?.postMessage({ type: "integration-test-result", status: "PASS", text: "HOST_UI_START_STOP=PASS" });
    } else if (status === "error") {
      hostUiTest.reported = true;
      window.chrome?.webview?.postMessage({ type: "integration-test-result", status: "FAIL", text: "HOST_UI_ERROR=" + detail });
    }
  }
}

function toggleHostPanel() {
  const willOpen = ui.hostPanel.classList.contains("hidden");
  ui.hostPanel.classList.toggle("hidden", !willOpen);
  ui.host.textContent = willOpen ? "收起主机" : "创建主机";
  if (willOpen && window.chrome?.webview) window.chrome.webview.postMessage({ type: "network-environment-check" });
  if (willOpen && !ui.hostPublicIp.value) detectPublicIp().catch(() => {});
}

async function detectPublicIp() {
  ui.detectPublicIp.disabled = true;
  ui.detectPublicIp.textContent = "检测中…";
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch("https://api4.ipify.org?format=json", { cache: "no-store", signal: controller.signal });
    if (!response.ok) throw new Error("HTTP " + response.status);
    const data = await response.json();
    ui.hostPublicIp.value = parseIpv4(data.ip);
    showToast(state.vpnDetected ? "检测到的是当前网络出口；请先查看 VPN 警告" : "已检测到公网 IPv4；仍需确认路由器不是 CGNAT");
  } catch (error) {
    showModalText("无法自动检测公网 IP", "请手动填写路由器的公网 IPv4。若运营商使用 CGNAT，本机不能直接作为公网主机。");
    throw error;
  } finally {
    clearTimeout(timeout);
    ui.detectPublicIp.disabled = state.turnHostStatus === "running";
    ui.detectPublicIp.textContent = "自动检测";
  }
}

function startOrStopTurnHost() {
  if (state.turnHostStatus === "running") {
    if (window.chrome?.webview) window.chrome.webview.postMessage({ type: "turn-host-stop" });
    return;
  }
  if (!window.chrome?.webview) {
    showModalText("仅桌面版可创建主机", "浏览器预览不能启动本机 TURN 服务，请运行 dlsgraph-p2p.exe。");
    return;
  }
  if (state.connected) {
    showModalText("请先断开房间", "TURN 配置必须在建立 WebRTC 连接前确定。请先断开房间，再启动本机主机。");
    return;
  }
  try {
    const config = readHostTurnConfig();
    const publicIp = parseIpv4(ui.hostPublicIp.value);
    const port = Number(ui.hostPort.value);
    state.pendingHostConfig = config;
    setTurnHostStatus("starting", "正在启动本机 TURN 主机…");
    window.chrome.webview.postMessage({
      type: "turn-host-start",
      publicIp,
      port,
      relayMin: TURN_RELAY_MIN,
      relayMax: TURN_RELAY_MAX,
      username: config.username,
      password: config.credential
    });
  } catch (error) {
    state.pendingHostConfig = null;
    setTurnHostStatus("error", error.message || String(error));
  }
}

async function connectRoom() {
  if (state.connected || state.connecting) {
    await disconnectRoom(true);
    return;
  }

  const name = ui.name.value.trim();
  const room = ui.room.value.trim();
  const secret = ui.secret.value;
  if (!name || !room || secret.length < 8) {
    showModalText("无法连接", "请填写昵称、房间名，以及至少 8 位的共享密钥。");
    return;
  }

  state.connecting = true;
  setConnectionBusy(true, "正在准备安全连接…");
  try {
    const server = await resolveServer(ui.server.value !== "auto");
    state.selfId = randomId(12);
    state.signalGeneration++;
    state.signalQueue = Promise.resolve();
    state.name = name;
    state.room = room;
    state.secret = secret;
    state.server = server;
    state.cryptoKey = await deriveCryptoKey(room, secret);
    state.topic = await createTopic(room, secret);
    state.connected = true;
    state.peers.clear();
    state.seenMessages.clear();

    await openSignaling();
    lockConnectionFields(true);
    state.heartbeatTimer = setInterval(() => sendSignal({ type: "join" }).catch(() => {}), 12000);
    state.cleanupTimer = setInterval(cleanupPeers, 5000);
    state.pingTimer = setInterval(pingAllPeers, 4000);
    addSystemMessage("已进入房间“" + room + "”；正在寻找其他成员并建立 P2P 连接。", false);
    renderMembers();
  } catch (error) {
    await disconnectRoom(false);
    showModalText("连接失败", error.message || String(error));
    setStatus("error", "连接失败");
  } finally {
    state.connecting = false;
    setConnectionBusy(false);
  }
}

async function openSignaling() {
  setStatus("connecting", "正在连接信令服务器…");
  const source = new EventSource(state.server + state.topic + "/sse?since=10s");
  state.eventSource = source;

  source.onmessage = event => handleSignalingEvent(event.data);
  source.onerror = () => {
    state.signalOpen = false;
    if (state.connected) setStatus("connecting", "信令连接中断，正在自动重连；已有 P2P 连接不受影响");
  };

  await new Promise((resolve, reject) => {
    let settled = false;
    const timeout = setTimeout(() => {
      if (settled) return;
      settled = true;
      reject(new Error("信令服务器连接超时"));
    }, 12000);
    source.onopen = async () => {
      state.signalOpen = true;
      setStatus("online", "已连接 · " + state.room);
      if (!settled) {
        settled = true;
        clearTimeout(timeout);
        resolve();
      }
      try { await sendSignal({ type: "join" }); } catch (_) {}
    };
  });
}

async function handleSignalingEvent(raw) {
  try {
    const relay = JSON.parse(raw);
    if (relay.event !== "message" || typeof relay.message !== "string") return;
    const message = await decryptObject(relay.message);
    await handleSignal(message);
  } catch (_) {
    // Ignore unrelated public-topic traffic or packets encrypted with another key.
  }
}

function sendSignal(message) {
  const generation = state.signalGeneration;
  const operation = state.signalQueue.then(() => publishSignal(message, generation));
  state.signalQueue = operation.catch(() => {});
  return operation;
}

async function publishSignal(message, generation) {
  if (!state.connected || !state.cryptoKey || generation !== state.signalGeneration) throw new Error("尚未连接");
  const packet = Object.assign({
    protocol: 1,
    from: state.selfId,
    name: state.name,
    sentAt: Date.now()
  }, message);
  const encrypted = await encryptObject(packet);
  let lastStatus = 0;
  for (let attempt = 0; attempt < 5; attempt++) {
    if (!state.connected || generation !== state.signalGeneration) throw new Error("连接已变化");
    if (attempt) await delay(250 * Math.pow(2, attempt - 1) + Math.random() * 180);
    const response = await fetch(state.server + state.topic + "?cache=no", {
      method: "POST",
      body: encrypted,
      cache: "no-store",
      keepalive: message.type === "leave"
    });
    lastStatus = response.status;
    if (response.ok) {
      await delay(90);
      return;
    }
    if (response.status !== 429 && response.status < 500) break;
  }
  throw new Error("信令发送失败：HTTP " + lastStatus);
}

async function handleSignal(message) {
  if (!message || message.protocol !== 1 || !message.from || message.from === state.selfId) return;
  if (message.to && message.to !== state.selfId) return;

  let peer = state.peers.get(message.from);
  if (peer) {
    peer.lastSeen = Date.now();
    if (message.name) peer.name = String(message.name).slice(0, 24);
  }

  switch (message.type) {
    case "join":
      const isNewJoin = !peer;
      if (!peer && state.peers.size >= MAX_MEMBERS - 1) {
        await sendSignal({ type: "room-full", to: message.from });
        return;
      }
      peer = ensurePeer(message.from, message.name);
      if (isNewJoin) {
        if (state.selfId < message.from) await makeOffer(peer, false);
        else sendSignal({ type: "welcome", to: message.from }).catch(() => {});
      } else if (state.selfId < message.from && peer.channel?.readyState !== "open" && Date.now() - peer.lastOfferAt > 7000) {
        await makeOffer(peer, true);
      }
      break;
    case "welcome":
      peer = ensurePeer(message.from, message.name);
      if (state.selfId < message.from) await makeOffer(peer, false);
      break;
    case "offer":
      peer = ensurePeer(message.from, message.name);
      await acceptOffer(peer, message.description);
      break;
    case "answer":
      peer = ensurePeer(message.from, message.name);
      if (peer.pc.signalingState === "have-local-offer") {
        await peer.pc.setRemoteDescription(message.description);
        await flushCandidates(peer);
      }
      break;
    case "candidate":
      peer = ensurePeer(message.from, message.name);
      if (message.candidate) {
        if (peer.pc.remoteDescription) await peer.pc.addIceCandidate(message.candidate);
        else peer.candidateQueue.push(message.candidate);
      }
      break;
    case "leave":
      removePeer(message.from, "已离开房间");
      break;
    case "room-full":
      showModalText("房间已满", "该房间已经有 5 名成员。请稍后重试或更换房间名。");
      break;
  }
  renderMembers();
}

function ensurePeer(remoteId, remoteName) {
  let existing = state.peers.get(remoteId);
  if (existing && existing.pc.connectionState !== "closed") {
    existing.lastSeen = Date.now();
    if (remoteName) existing.name = String(remoteName).slice(0, 24);
    return existing;
  }
  if (state.peers.size >= MAX_MEMBERS - 1) throw new Error("房间人数已达上限");

  const pc = new RTCPeerConnection(getIceConfiguration());
  const peer = {
    id: remoteId,
    name: String(remoteName || "成员").slice(0, 24),
    pc,
    channel: null,
    candidateQueue: [],
    makingOffer: false,
    offerStarted: false,
    lastOfferAt: 0,
    lastSeen: Date.now(),
    rtt: null,
    path: "正在协商",
    pendingPings: new Map(),
    testSamples: [],
    testExpected: 0,
    restartScheduled: false,
    collectingIce: false,
    integrationStarted: false,
    integrationVerified: false,
    integrationToken: ""
  };
  state.peers.set(remoteId, peer);

  pc.onicecandidate = event => {
    if (event.candidate && !peer.collectingIce)
      sendSignal({ type: "candidate", to: remoteId, candidate: event.candidate.toJSON() }).catch(() => {});
  };
  pc.ondatachannel = event => attachDataChannel(peer, event.channel);
  pc.onconnectionstatechange = () => handlePeerConnectionState(peer);
  return peer;
}

async function makeOffer(peer, iceRestart) {
  if (!peer || peer.makingOffer || !state.connected) return;
  if (!iceRestart && peer.offerStarted) return;
  peer.makingOffer = true;
  peer.offerStarted = true;
  peer.lastOfferAt = Date.now();
  try {
    if (iceRestart && peer.pc.signalingState !== "stable") {
      try { await peer.pc.setLocalDescription({ type: "rollback" }); } catch (_) {}
    }
    if (!peer.channel || peer.channel.readyState === "closed") {
      attachDataChannel(peer, peer.pc.createDataChannel("dlsgraph-chat", { ordered: true }));
    }
    const offer = await peer.pc.createOffer({ iceRestart: !!iceRestart });
    peer.collectingIce = true;
    await peer.pc.setLocalDescription(offer);
    await waitForIceGathering(peer.pc, 1800);
    await sendSignal({ type: "offer", to: peer.id, description: peer.pc.localDescription });
    peer.collectingIce = false;
  } finally {
    peer.collectingIce = false;
    peer.makingOffer = false;
  }
}

async function acceptOffer(peer, description) {
  if (!description) return;
  if (peer.pc.signalingState !== "stable") {
    try { await peer.pc.setLocalDescription({ type: "rollback" }); } catch (_) {}
  }
  await peer.pc.setRemoteDescription(description);
  await flushCandidates(peer);
  const answer = await peer.pc.createAnswer();
  peer.collectingIce = true;
  await peer.pc.setLocalDescription(answer);
  await waitForIceGathering(peer.pc, 1800);
  await sendSignal({ type: "answer", to: peer.id, description: peer.pc.localDescription });
  peer.collectingIce = false;
}

function waitForIceGathering(pc, timeoutMs) {
  if (pc.iceGatheringState === "complete") return Promise.resolve();
  return new Promise(resolve => {
    let finished = false;
    const done = () => {
      if (finished) return;
      finished = true;
      pc.removeEventListener("icegatheringstatechange", changed);
      clearTimeout(timer);
      resolve();
    };
    const changed = () => { if (pc.iceGatheringState === "complete") done(); };
    const timer = setTimeout(done, timeoutMs);
    pc.addEventListener("icegatheringstatechange", changed);
  });
}

async function flushCandidates(peer) {
  const candidates = peer.candidateQueue.splice(0);
  for (const candidate of candidates) {
    try { await peer.pc.addIceCandidate(candidate); } catch (_) {}
  }
}

function attachDataChannel(peer, channel) {
  if (peer.channel && peer.channel !== channel) {
    try { peer.channel.close(); } catch (_) {}
  }
  peer.channel = channel;
  channel.onopen = async () => {
    peer.path = "P2P 直连";
    peer.restartScheduled = false;
    await updatePeerPath(peer);
    sendPing(peer, false);
    addSystemMessage("已与“" + peer.name + "”建立 WebRTC 连接（" + peer.path + "）。", false);
    renderMembers();
  };
  channel.onclose = () => {
    if (state.connected) {
      peer.path = "WebRTC 已断开";
      peer.rtt = null;
      renderMembers();
    }
  };
  channel.onerror = () => {
    peer.path = "WebRTC 连接失败";
    peer.rtt = null;
    renderMembers();
  };
  channel.onmessage = event => handleDataMessage(peer, event.data);
}

async function handleDataMessage(peer, data) {
  try {
    if (typeof data !== "string") return;
    if (data.startsWith(SIGNAL_PREFIX)) {
      const packet = await decryptObject(data);
      if (packet.kind === "integration-ping" && packet.token && peer.channel?.readyState === "open") {
        peer.channel.send(await encryptObject({ kind: "integration-ack", token: packet.token }));
      } else if (packet.kind === "integration-ack" && integration.enabled && packet.token === peer.integrationToken) {
        peer.integrationVerified = true;
        reportIntegrationResult();
      } else {
        await acceptChatPacket(packet, peer.path);
      }
      return;
    }
    const control = JSON.parse(data);
    if (control.kind === "ping" && control.id) {
      if (peer.channel?.readyState === "open") peer.channel.send(JSON.stringify({ kind: "pong", id: control.id }));
    } else if (control.kind === "pong" && control.id) {
      completePing(peer, control.id);
    }
  } catch (_) {}
}

function handlePeerConnectionState(peer) {
  const status = peer.pc.connectionState;
  if (status === "connected") {
    peer.path = "P2P 直连";
    updatePeerPath(peer).catch(() => {});
  } else if (status === "failed" || status === "disconnected") {
    peer.path = status === "failed" ? "WebRTC 连接失败" : "WebRTC 已断开";
    peer.rtt = null;
    if (status === "failed" && !peer.restartScheduled && state.selfId < peer.id) {
      peer.restartScheduled = true;
      setTimeout(() => makeOffer(peer, true).catch(() => {}), 1800);
    }
  } else if (status === "connecting") {
    peer.path = "正在协商";
  }
  renderMembers();
}

async function updatePeerPath(peer) {
  try {
    const stats = await peer.pc.getStats();
    let pair = null;
    stats.forEach(report => {
      if (report.type === "transport" && report.selectedCandidatePairId) pair = stats.get(report.selectedCandidatePairId);
    });
    if (!pair) {
      stats.forEach(report => {
        if (report.type === "candidate-pair" && report.state === "succeeded" && report.nominated) pair = report;
      });
    }
    if (pair) {
      const local = stats.get(pair.localCandidateId);
      const remote = stats.get(pair.remoteCandidateId);
      const relayed = local?.candidateType === "relay" || remote?.candidateType === "relay";
      peer.path = relayed ? "TURN 中继" : "P2P 直连";
    }
  } catch (_) {}
  renderMembers();
}

async function sendCurrentMessage() {
  if (!state.connected) return;
  const text = ui.message.value.trim();
  if (!text) return;
  const peers = Array.from(state.peers.values());
  if (!peers.length) {
    showToast("尚无其他成员，消息未发送");
    return;
  }
  const activePeers = peers.filter(peer => peer.channel?.readyState === "open");
  if (!activePeers.length) {
    showModalText("消息未发送", "当前没有可用的 WebRTC 链路。请等待 P2P 直连或 TURN 中继建立后再发送。");
    return;
  }
  const packet = {
    kind: "chat",
    id: randomId(16),
    from: state.selfId,
    name: state.name,
    text,
    sentAt: Date.now()
  };
  state.seenMessages.add(packet.id);
  const encrypted = await encryptObject(packet);
  let deliveredCount = 0;
  activePeers.forEach(peer => {
    try { peer.channel.send(encrypted); deliveredCount++; }
    catch (_) {}
  });
  if (!deliveredCount) {
    showToast("WebRTC 链路已断开，消息未发送");
    return;
  }
  const missed = peers.length - deliveredCount;
  addChatMessage(packet, true, "WebRTC 送达 " + deliveredCount + "/" + peers.length + (missed ? " · " + missed + " 人未送达" : ""));
  if (missed) showToast(missed + " 名成员尚未建立链路，消息未向其发送");
  ui.message.value = "";
  ui.message.focus();
}

async function acceptChatPacket(packet, route) {
  if (!packet || packet.kind !== "chat" || !packet.id || !packet.from || !packet.text) return;
  if (state.seenMessages.has(packet.id)) return;
  state.seenMessages.add(packet.id);
  if (state.seenMessages.size > 1500) state.seenMessages.clear();
  addChatMessage(packet, false, route);
}

function sendPing(peer, isTest) {
  if (!peer.channel || peer.channel.readyState !== "open") return;
  const id = randomId(8);
  peer.pendingPings.set(id, { started: performance.now(), test: !!isTest });
  if (isTest) peer.testExpected++;
  try { peer.channel.send(JSON.stringify({ kind: "ping", id })); }
  catch (_) { peer.pendingPings.delete(id); }
  setTimeout(() => peer.pendingPings.delete(id), 3500);
}

function completePing(peer, id) {
  const pending = peer.pendingPings.get(id);
  if (!pending) return;
  peer.pendingPings.delete(id);
  const rtt = Math.max(0, Math.round(performance.now() - pending.started));
  peer.rtt = rtt;
  if (pending.test) peer.testSamples.push(rtt);
  renderMembers();
  if (integration.enabled && !peer.integrationStarted) {
    peer.integrationStarted = true;
    peer.integrationToken = randomId(12);
    encryptObject({ kind: "integration-ping", token: peer.integrationToken })
      .then(payload => peer.channel.send(payload))
      .catch(() => {});
  } else {
    reportIntegrationResult();
  }
}

function reportIntegrationResult() {
  if (!integration.enabled || integration.reported || integration.completing) return;
  const peers = Array.from(state.peers.values());
  if (peers.length < integration.expected - 1) return;
  if (!peers.every(peer => peer.channel?.readyState === "open"
      && (!integration.forceRelay || peer.path.includes("TURN"))
      && Number.isFinite(peer.rtt) && peer.integrationVerified)) return;
  integration.completing = true;
  setTimeout(() => {
    integration.completing = false;
    if (integration.reported) return;
    const stablePeers = Array.from(state.peers.values());
    if (stablePeers.length < integration.expected - 1 || !stablePeers.every(peer => peer.channel?.readyState === "open"
        && (!integration.forceRelay || peer.path.includes("TURN"))
        && Number.isFinite(peer.rtt) && peer.integrationVerified)) return;
    integration.reported = true;
    const latencies = stablePeers.map(peer => peer.rtt);
    const maximum = Math.max(...latencies);
    const average = Math.round(latencies.reduce((a, b) => a + b, 0) / latencies.length);
    const passed = maximum < 100;
    if (window.chrome?.webview) {
      window.chrome.webview.postMessage({
        type: "integration-test-result",
        status: passed ? "PASS" : "FAIL",
        text: "ROLE=" + integration.role + " CONNECTED=" + stablePeers.length + "/" + (integration.expected - 1)
          + " ROUTE=" + (integration.forceRelay ? "TURN" : "AUTO")
          + " AVG_RTT_MS=" + average + " MAX_RTT_MS=" + maximum + " AES_GCM=PASS"
      });
    }
  }, 3000);
}

function pingAllPeers() {
  state.peers.forEach(peer => sendPing(peer, false));
}

async function runQualityTest() {
  const directPeers = Array.from(state.peers.values()).filter(peer => peer.channel?.readyState === "open");
  if (!directPeers.length || state.qualityRunning) {
    showToast("当前没有可测试的 WebRTC 连接");
    return;
  }
  state.qualityRunning = true;
  ui.quality.disabled = true;
  ui.quality.textContent = "测试中…";
  directPeers.forEach(peer => { peer.testSamples = []; peer.testExpected = 0; });
  for (let round = 0; round < 5; round++) {
    directPeers.forEach(peer => sendPing(peer, true));
    await delay(350);
  }
  await delay(1800);

  const body = document.createElement("div");
  directPeers.forEach(peer => {
    const samples = peer.testSamples.slice();
    const row = document.createElement("div");
    row.className = "result-row";
    const left = document.createElement("div");
    const title = document.createElement("strong");
    title.textContent = peer.name + " · " + peer.path;
    const detail = document.createElement("div");
    if (samples.length) {
      const average = Math.round(samples.reduce((a, b) => a + b, 0) / samples.length);
      const loss = Math.round((1 - samples.length / Math.max(1, peer.testExpected)) * 100);
      detail.textContent = "最低 " + Math.min(...samples) + " ms · 最高 " + Math.max(...samples) + " ms · 丢包 " + loss + "%";
      const right = document.createElement("span");
      right.className = latencyClass(average);
      right.textContent = "平均 " + average + " ms" + (average < 100 && loss === 0 ? " · 达标" : " · 未达标");
      left.append(title, detail);
      row.append(left, right);
    } else {
      detail.textContent = "未收到测试响应";
      left.append(title, detail);
      const right = document.createElement("span");
      right.className = "latency-bad";
      right.textContent = "失败";
      row.append(left, right);
    }
    body.appendChild(row);
  });
  showModal("WebRTC 链路自检（5 轮）", body);
  state.qualityRunning = false;
  ui.quality.textContent = "链路自检";
  ui.quality.disabled = state.peers.size === 0;
}

async function disconnectRoom(showMessage) {
  if (state.connected) {
    try { await Promise.race([sendSignal({ type: "leave" }), delay(500)]); } catch (_) {}
  }
  state.connected = false;
  state.signalGeneration++;
  state.signalOpen = false;
  [state.heartbeatTimer, state.cleanupTimer, state.pingTimer].forEach(timer => timer && clearInterval(timer));
  state.heartbeatTimer = state.cleanupTimer = state.pingTimer = null;
  if (state.eventSource) state.eventSource.close();
  state.eventSource = null;
  state.peers.forEach(peer => {
    try { peer.channel?.close(); } catch (_) {}
    try { peer.pc.close(); } catch (_) {}
  });
  state.peers.clear();
  state.cryptoKey = null;
  lockConnectionFields(false);
  setStatus("idle", "尚未连接");
  if (showMessage) addSystemMessage("已断开房间。", false);
  renderMembers();
}

function cleanupPeers() {
  const now = Date.now();
  state.peers.forEach(peer => {
    if (now - peer.lastSeen > 42000) removePeer(peer.id, "连接超时");
  });
}

function removePeer(id, reason) {
  const peer = state.peers.get(id);
  if (!peer) return;
  try { peer.channel?.close(); } catch (_) {}
  try { peer.pc.close(); } catch (_) {}
  state.peers.delete(id);
  addSystemMessage("“" + peer.name + "”" + reason + "。", false);
  renderMembers();
}

function renderMembers() {
  ui.members.replaceChildren();
  if (!state.connected) {
    const empty = document.createElement("div");
    empty.className = "empty-state small";
    empty.textContent = "连接后显示成员及各自延时";
    ui.members.appendChild(empty);
    ui.memberCount.textContent = "0 / " + MAX_MEMBERS;
    ui.quality.disabled = true;
    updateSummary();
    return;
  }
  ui.members.appendChild(createMemberElement({ id: state.selfId, name: state.name, path: "本机", rtt: 0 }, true));
  Array.from(state.peers.values()).sort((a, b) => a.name.localeCompare(b.name, "zh-CN"))
    .forEach(peer => ui.members.appendChild(createMemberElement(peer, false)));
  ui.memberCount.textContent = (state.peers.size + 1) + " / " + MAX_MEMBERS;
  ui.quality.disabled = state.peers.size === 0 || state.qualityRunning;
  updateSummary();
}

function createMemberElement(peer, self) {
  const root = document.createElement("div");
  root.className = "member" + (self ? " self" : "");
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = (peer.name || "?").slice(0, 1).toUpperCase();
  const info = document.createElement("div");
  const name = document.createElement("div");
  name.className = "member-name";
  name.textContent = peer.name + (self ? "（我）" : "");
  const meta = document.createElement("div");
  meta.className = "member-meta";
  meta.textContent = self ? "本地节点" : "节点 " + peer.id.slice(0, 6);
  info.append(name, meta);
  const metrics = document.createElement("div");
  metrics.className = "member-metrics";
  const latency = document.createElement("strong");
  latency.textContent = self ? "0 ms" : (peer.rtt == null ? "--" : peer.rtt + " ms");
  latency.className = self ? "latency-good" : latencyClass(peer.rtt);
  const path = document.createElement("span");
  path.textContent = peer.path;
  path.className = peer.path === "P2P 直连" ? "path-direct"
    : (peer.path.includes("TURN") ? "path-turn"
      : (peer.path.includes("失败") || peer.path.includes("断开") ? "path-relay" : "path-connecting"));
  metrics.append(latency, path);
  root.append(avatar, info, metrics);
  return root;
}

function updateSummary() {
  const peers = Array.from(state.peers.values());
  const active = peers.filter(peer => peer.channel?.readyState === "open");
  const relayed = active.filter(peer => peer.path.includes("TURN"));
  const direct = active.filter(peer => !peer.path.includes("TURN"));
  const latencies = active.map(peer => peer.rtt).filter(value => Number.isFinite(value));
  ui.directSummary.textContent = direct.length + "/" + peers.length;
  ui.turnSummary.textContent = relayed.length
    ? relayed.length + " 条"
    : (state.turnConfig ? (state.turnConfigSource === "host" ? "本机主机" : "已配置") : "未配置");
  ui.averageLatency.textContent = latencies.length
    ? Math.round(latencies.reduce((a, b) => a + b, 0) / latencies.length) + " ms"
    : "--";
  if (!state.connected) ui.routeBadge.textContent = "等待连接";
  else if (!peers.length) ui.routeBadge.textContent = "等待成员";
  else if (direct.length === peers.length) ui.routeBadge.textContent = "全部 P2P 直连";
  else if (active.length === peers.length) ui.routeBadge.textContent = direct.length + " 直连 · " + relayed.length + " TURN";
  else ui.routeBadge.textContent = direct.length + " 直连 · " + relayed.length + " TURN · " + (peers.length - active.length) + " 未连";
  const canSend = state.connected && active.length > 0;
  ui.message.disabled = !canSend;
  ui.send.disabled = !canSend;
  ui.message.placeholder = canSend
    ? "输入消息；Enter 发送，Shift+Enter 换行"
    : (state.connected ? "等待建立 P2P 或 TURN 链路…" : "连接房间后可发送消息");
}

function latencyClass(value) {
  if (!Number.isFinite(value)) return "";
  if (value < 100) return "latency-good";
  if (value < 200) return "latency-warn";
  return "latency-bad";
}

function addChatMessage(packet, mine, delivery) {
  if (ui.messageEmpty) ui.messageEmpty.remove();
  const row = document.createElement("div");
  row.className = "message-row" + (mine ? " mine" : "");
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  const head = document.createElement("div");
  head.className = "bubble-head";
  const sender = document.createElement("span");
  sender.textContent = mine ? "我" : String(packet.name || "成员").slice(0, 24);
  const time = document.createElement("span");
  time.textContent = new Date(packet.sentAt || Date.now()).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" });
  head.append(sender, time);
  const text = document.createElement("div");
  text.className = "bubble-text";
  text.textContent = String(packet.text).slice(0, 1800);
  const route = document.createElement("div");
  route.className = "delivery";
  route.textContent = delivery;
  bubble.append(head, text, route);
  row.appendChild(bubble);
  ui.messages.appendChild(row);
  while (ui.messages.children.length > 250) ui.messages.firstElementChild.remove();
  ui.messages.scrollTop = ui.messages.scrollHeight;
}

function addSystemMessage(text, important) {
  if (ui.messageEmpty) ui.messageEmpty.remove();
  const item = document.createElement("div");
  item.className = "system-message";
  item.textContent = text;
  if (important) item.style.color = "#dc2626";
  ui.messages.appendChild(item);
  ui.messages.scrollTop = ui.messages.scrollHeight;
}

function makeInvite(server, room, secret, turnConfig = state.turnConfig) {
  const normalized = normalizeServer(server);
  const turn = turnConfig ? normalizeTurnConfig(turnConfig) : null;
  const code = INVITE_PREFIX + [normalized, room, secret, JSON.stringify(turn)].map(textToBase64Url).join("|");
  const lines = [
    "dlsgraph P2P 邀请 v4",
    turn ? "模式：WebRTC P2P 直连优先，TURN 加密中继兜底（最多 5 人）" : "模式：仅 WebRTC P2P Mesh（最多 5 人）",
    "信令服务器：" + normalized,
    "房间名：" + room,
    "共享密钥：" + secret
  ];
  if (turn) {
    lines.push("TURN 地址：" + turn.urls.join(","));
    lines.push("TURN 用户：" + turn.username);
    lines.push("TURN 密码：" + turn.credential);
  }
  lines.push("邀请代码：" + code);
  return lines.join("\r\n");
}

function parseInvite(text) {
  const lines = String(text || "").replace(/\r/g, "").split("\n").map(line => line.trim());
  for (const line of lines) {
    const index = line.indexOf(INVITE_PREFIX);
    if (index >= 0) {
      const parts = line.slice(index).split("|");
      if (parts.length === 5) {
        const decodedTurn = JSON.parse(base64UrlToText(parts[4]));
        return {
          server: normalizeServer(base64UrlToText(parts[1])),
          room: base64UrlToText(parts[2]),
          secret: base64UrlToText(parts[3]),
          turn: decodedTurn ? normalizeTurnConfig(decodedTurn) : null
        };
      }
    }
    const legacyP2PIndex = line.indexOf(LEGACY_INVITE_PREFIX);
    if (legacyP2PIndex >= 0) {
      const parts = line.slice(legacyP2PIndex).split("|");
      if (parts.length === 4) {
        return { server: normalizeServer(base64UrlToText(parts[1])), room: base64UrlToText(parts[2]), secret: base64UrlToText(parts[3]), turn: null };
      }
    }
    const legacyIndex = line.indexOf("DLSGRAPH2|");
    if (legacyIndex >= 0) {
      const parts = line.slice(legacyIndex).split("|");
      if (parts.length === 4) {
        return { server: normalizeServer(base64UrlToText(parts[1])), room: base64UrlToText(parts[2]), secret: base64UrlToText(parts[3]), turn: null };
      }
    }
  }
  const result = {};
  for (const line of lines) {
    if (line.startsWith("信令服务器：")) result.server = line.slice(6).trim();
    else if (line.startsWith("服务器：")) result.server = line.slice(4).trim();
    else if (line.startsWith("房间名：")) result.room = line.slice(4).trim();
    else if (line.startsWith("共享密钥：")) result.secret = line.slice(5).trim();
    else if (line.startsWith("TURN 地址：")) result.turnUrls = line.slice(8).trim().split(",");
    else if (line.startsWith("TURN 用户：")) result.turnUsername = line.slice(8).trim();
    else if (line.startsWith("TURN 密码：")) result.turnCredential = line.slice(8).trim();
  }
  if (!result.server || !result.room || !result.secret) throw new Error("剪贴板中没有完整的 dlsgraph 邀请");
  result.server = normalizeServer(result.server);
  result.turn = result.turnUrls || result.turnUsername || result.turnCredential
    ? normalizeTurnConfig({ urls: result.turnUrls, username: result.turnUsername, credential: result.turnCredential })
    : null;
  return result;
}

function runAppSelfChecks() {
  const expectedTurn = normalizeTurnConfig({
    urls: ["turn:203.0.113.8:3478?transport=udp", "turn:203.0.113.8:3478?transport=tcp"],
    username: "dls-check",
    credential: "dls-check-password"
  });
  const current = parseInvite(makeInvite("https://ntfy.sh/", "check-room", "check-secret", expectedTurn));
  if (current.room !== "check-room" || current.secret !== "check-secret" || current.turn?.urls.length !== 2
      || current.turn.username !== expectedTurn.username || current.turn.credential !== expectedTurn.credential)
    throw new Error("邀请 v4 自检失败");

  const legacyCode = LEGACY_INVITE_PREFIX
    + ["https://ntfy.sh/", "legacy-room", "legacy-secret"].map(textToBase64Url).join("|");
  const legacy = parseInvite(legacyCode);
  if (legacy.room !== "legacy-room" || legacy.secret !== "legacy-secret" || legacy.turn)
    throw new Error("旧邀请兼容自检失败");
  return true;
}

async function copyInvite() {
  const room = ui.room.value.trim();
  const secret = ui.secret.value;
  if (!room || secret.length < 8) {
    showModalText("无法复制", "请先填写房间名和至少 8 位的共享密钥。");
    return;
  }
  try {
    const server = state.connected ? state.server : await resolveServer(false);
    const invitation = makeInvite(server, room, secret);
    if (window.chrome?.webview) window.chrome.webview.postMessage({ type: "clipboard-write", text: invitation });
    else await navigator.clipboard.writeText(invitation);
    showToast(state.turnConfig ? "已复制包含信令与 TURN 主机的邀请" : "已复制 P2P 邀请");
  } catch (error) {
    showModalText("复制失败", error.message || String(error));
  }
}

function requestPasteInvite() {
  if (state.connected) {
    showToast("请先断开当前房间");
    return;
  }
  if (window.chrome?.webview) window.chrome.webview.postMessage({ type: "clipboard-read" });
  else navigator.clipboard.readText().then(importInvite).catch(error => showModalText("读取失败", error.message));
}

function importInvite(text) {
  try {
    const invitation = parseInvite(text);
    ui.room.value = invitation.room;
    ui.secret.value = invitation.secret;
    state.turnConfig = invitation.turn || null;
    state.turnConfigSource = invitation.turn ? "invite" : "";
    ui.turnSummary.textContent = invitation.turn ? "已配置" : "未配置";
    const option = Array.from(ui.server.options).find(item => item.value === invitation.server);
    if (option) {
      ui.server.value = invitation.server;
      ui.customServer.classList.add("hidden");
    } else {
      ui.server.value = "custom";
      ui.customServer.value = invitation.server;
      ui.customServer.classList.remove("hidden");
    }
    setStatus("idle", "邀请已导入 · " + new URL(invitation.server).hostname + (invitation.turn ? " · TURN 已配置" : ""));
    showToast(invitation.turn ? "信令、房间、密钥和 TURN 主机已导入" : "服务器、房间和密钥已全部导入");
  } catch (error) {
    showModalText("邀请格式不正确", error.message || String(error));
  }
}

function setStatus(kind, text) {
  ui.statusDot.className = "status-dot " + kind;
  ui.statusText.textContent = text;
}

function setConnectionBusy(busy, text) {
  ui.probe.disabled = busy;
  ui.copyInvite.disabled = busy;
  ui.pasteInvite.disabled = busy;
  ui.connect.disabled = busy;
  if (busy && text) setStatus("connecting", text);
  if (!busy && !state.connected) {
    ui.probe.disabled = false;
    ui.copyInvite.disabled = false;
    ui.pasteInvite.disabled = false;
    ui.connect.disabled = false;
  }
}

function lockConnectionFields(connected) {
  ui.name.disabled = connected;
  ui.room.disabled = connected;
  ui.secret.disabled = connected;
  ui.showSecret.disabled = connected;
  ui.randomSecret.disabled = connected;
  ui.server.disabled = connected;
  ui.customServer.disabled = connected;
  ui.probe.disabled = connected;
  ui.pasteInvite.disabled = connected;
  ui.host.disabled = connected && state.turnHostStatus !== "running";
  ui.startHost.disabled = state.turnHostStatus === "starting" || (connected && state.turnHostStatus !== "running");
  ui.connect.textContent = connected ? "断开房间" : "连接房间";
  ui.message.disabled = true;
  ui.send.disabled = true;
}

function showToast(text) {
  ui.toast.textContent = text;
  ui.toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => ui.toast.classList.remove("show"), 1800);
}

function showModal(title, bodyNode) {
  ui.modalTitle.textContent = title;
  ui.modalBody.replaceChildren(bodyNode);
  ui.modalBackdrop.classList.remove("hidden");
}

function showModalText(title, text) {
  const paragraph = document.createElement("p");
  paragraph.textContent = text;
  showModal(title, paragraph);
}

function closeModal() {
  ui.modalBackdrop.classList.add("hidden");
}

function delay(milliseconds) {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
}

ui.server.addEventListener("change", () => ui.customServer.classList.toggle("hidden", ui.server.value !== "custom"));
ui.host.addEventListener("click", toggleHostPanel);
ui.detectPublicIp.addEventListener("click", () => detectPublicIp().catch(() => {}));
ui.startHost.addEventListener("click", startOrStopTurnHost);
ui.randomSecret.addEventListener("click", () => { ui.secret.value = randomSecret(); });
ui.showSecret.addEventListener("click", () => {
  const show = ui.secret.type === "password";
  ui.secret.type = show ? "text" : "password";
  ui.showSecret.textContent = show ? "隐藏" : "显示";
});
ui.probe.addEventListener("click", () => autoSelectServer(true).catch(() => {}));
ui.copyInvite.addEventListener("click", copyInvite);
ui.pasteInvite.addEventListener("click", requestPasteInvite);
ui.connect.addEventListener("click", connectRoom);
ui.send.addEventListener("click", () => sendCurrentMessage().catch(error => showToast(error.message)));
ui.quality.addEventListener("click", runQualityTest);
ui.message.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendCurrentMessage().catch(error => showToast(error.message));
  }
});
ui.modalClose.addEventListener("click", closeModal);
ui.modalConfirm.addEventListener("click", closeModal);
ui.modalBackdrop.addEventListener("click", event => { if (event.target === ui.modalBackdrop) closeModal(); });

if (window.chrome?.webview) {
  window.chrome.webview.addEventListener("message", event => {
    const message = event.data || {};
    if (message.type === "clipboard-content") importInvite(message.text);
    else if (message.type === "turn-host-status") setTurnHostStatus(message.status || "error", message.detail || "");
    else if (message.type === "network-environment") {
      state.vpnDetected = !!message.vpnDetected;
      ui.hostNetworkWarning.classList.toggle("hidden", !state.vpnDetected);
      ui.hostNetworkWarning.textContent = state.vpnDetected
        ? "检测到正在运行的 VPN / 隧道网卡。自动检测结果可能是 VPN 出口，通常不能作为 TURN 主机地址；请关闭 VPN 后重新检测，或确认 VPN 服务提供端口转发。"
        : "";
    }
    else if (message.type === "host-error") showModalText("桌面组件错误", message.message || "未知错误");
  });
}

window.addEventListener("beforeunload", () => {
  if (state.connected) sendSignal({ type: "leave" }).catch(() => {});
});

ui.name.value = ("用户-" + randomId(2)).slice(0, 24);
ui.secret.value = randomSecret();
ui.hostUsername.value = ("dls-" + randomId(4)).slice(0, 48);
ui.hostPassword.value = randomSecret() + randomId(4);
setTurnHostStatus("stopped", "");
renderMembers();
if (window.chrome?.webview) {
  try {
    runAppSelfChecks();
    window.chrome.webview.postMessage({ type: "app-ready", ok: true });
  } catch (error) {
    window.chrome.webview.postMessage({ type: "app-ready", ok: false, detail: error.message || String(error) });
  }
}

if (integration.enabled) {
  const params = new URLSearchParams(location.search);
  const server = normalizeServer(params.get("server"));
  ui.name.value = "测试-" + integration.role;
  ui.room.value = params.get("room") || "integration-room";
  ui.secret.value = params.get("secret") || "integration-secret";
  const turnUrl = params.get("turn");
  if (turnUrl) {
    state.turnConfig = normalizeTurnConfig({
      urls: [turnUrl],
      username: params.get("turnUser"),
      credential: params.get("turnPassword")
    });
    state.turnConfigSource = "invite";
    ui.turnSummary.textContent = "已配置";
  }
  const known = Array.from(ui.server.options).find(option => option.value === server);
  if (known) ui.server.value = server;
  else {
    ui.server.value = "custom";
    ui.customServer.value = server;
    ui.customServer.classList.remove("hidden");
  }
  setTimeout(() => connectRoom(), 300);
  setTimeout(() => {
    if (!integration.reported && window.chrome?.webview) {
      integration.reported = true;
      const peers = Array.from(state.peers.values());
      const direct = peers.filter(peer => peer.channel?.readyState === "open");
      const verified = peers.filter(peer => peer.integrationVerified);
      const details = peers.map(peer => peer.id.slice(0, 4) + ":" + peer.pc.connectionState + ":" + peer.path).join(",");
      window.chrome.webview.postMessage({
        type: "integration-test-result",
        status: "FAIL",
        text: "ROLE=" + integration.role + " TIMEOUT SIGNAL=" + state.signalOpen + " PEERS=" + peers.length
          + " DIRECT=" + direct.length + " VERIFIED=" + verified.length + " DETAILS=" + details
      });
    }
  }, 45000);
}

if (hostUiTest.enabled) {
  const params = new URLSearchParams(location.search);
  ui.hostPublicIp.value = params.get("hostIp") || "127.0.0.1";
  ui.hostPort.value = "3480";
  ui.hostUsername.value = "dls-host-ui-test";
  ui.hostPassword.value = "dls-host-ui-password";
  setTimeout(startOrStopTurnHost, 300);
  setTimeout(() => {
    if (hostUiTest.reported) return;
    hostUiTest.reported = true;
    window.chrome?.webview?.postMessage({ type: "integration-test-result", status: "FAIL", text: "HOST_UI_TIMEOUT" });
  }, 15000);
}
